using Microsoft.VisualStudio.TestTools.UnitTesting;
using InterviewTasks;

namespace IntersectArraysTests
{
	// Task: implement one positive test-case for IntersectArrays.IntersectTwoArrays().
	// Restrictions: you CAN use any Unit Testing Framework you like.

    [TestClass]
    public class IntersectArraysTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
