﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewTasks
{
    // Task: implement method "IntersectTwoArrays" so that it returns intersection of items presented in array1 and array2.
    // Restrictions: you can use all features of .Net except for those that contains the algorithm (eg. IEnumerable.Intersect()).
	// Complexity of implemented algorithm must be less than O(n*m).

    public static class IntersectArrays
    {
        public static string[] IntersectTwoArrays(string[] array1, string[] array2)
        {
            return null;
        }
    }
}
